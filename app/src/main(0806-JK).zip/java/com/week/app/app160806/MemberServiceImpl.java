package com.week.app.app160806;

/**
 * Created by Jaekeun_Lee on 2016-08-07.
 */
import android.content.Context;
import android.util.Log;

/**
 * Created by 1027 on 2016-08-06.
 */
public class MemberServiceImpl implements MemberService {
    MemberDAO dao;

    public MemberServiceImpl(Context context) {
        this.dao = new MemberDAO(context);
    }

    @Override
    public void login(MemberBean member) {
        Log.d("서비스:Login ID 체크",member.getId());
    }

    @Override
    public void join(MemberBean member) {
        Log.d("서비스:Join ID 체크",member.getId());
        dao.join(member);
    }
}



package com.week.app.app160806.util;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.week.app.app160806.R;

public class ImageActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
    }

    @Override
    public void onClick(View v) {

    }
}

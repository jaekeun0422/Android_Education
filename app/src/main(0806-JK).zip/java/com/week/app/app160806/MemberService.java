package com.week.app.app160806;

/**
 * Created by Jaekeun_Lee on 2016-08-07.
 */
public interface MemberService {
    public void login (MemberBean member);
    public void join (MemberBean member);
}